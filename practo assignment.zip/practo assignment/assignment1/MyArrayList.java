import org.junit.Before;
import org.junit.Test;
import java.util.NoSuchElementException;
import static org.junit.Assert.*;

public class MyArrayListTest {

    private MyArrayList<Integer> myArrayList;

    @Before
    public void setUp() {
        myArrayList = new MyArrayList<>();
        myArrayList.add(1);
        myArrayList.add(2);
        myArrayList.add(3);
    }

    @Test
    public void testAddAndGet() {
        assertEquals(3, myArrayList.size());
        assertEquals(Integer.valueOf(1), myArrayList.get(0));
        assertEquals(Integer.valueOf(2), myArrayList.get(1));
        assertEquals(Integer.valueOf(3), myArrayList.get(2));
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testGetIndexOutOfBounds() {
        myArrayList.get(3); // Index out of bounds (valid indexes are 0 to 2)
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testGetNegativeIndex() {
        myArrayList.get(-1); // Index out of bounds (negative index)
    }

    @Test(expected = NoSuchElementException.class)
    public void testGetEmptyList() {
        MyArrayList<Integer> emptyList = new MyArrayList<>();
        emptyList.get(0); // Attempting to get from an empty list
    }

    @Test
    public void testClear() {
        myArrayList.clear();
        assertEquals(0, myArrayList.size());
    }

    @Test
    public void testSize() {
        assertEquals(3, myArrayList.size());
        myArrayList.add(4);
        assertEquals(4, myArrayList.size());
    }

    @Test
    public void testAddAndGetLargeList() {
        MyArrayList<String> largeList = new MyArrayList<>();
        for (int i = 0; i < 1000; i++) {
            largeList.add("Element " + i);
        }
        assertEquals(1000, largeList.size());
        assertEquals("Element 500", largeList.get(500));
        assertEquals("Element 999", largeList.get(999));
    }
}
