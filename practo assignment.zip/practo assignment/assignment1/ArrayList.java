import java.util.ArrayList;
import java.util.List;

public class MyArrayList<T> {

    private List<T> list;

    public MyArrayList() {
        this.list = new ArrayList<>();
    }

    public void add(T item) {
        list.add(item);
    }

    public T get(int index) {
        return list.get(index);
    }

    public int size() {
        return list.size();
    }

    public void clear() {
        list.clear();
    }
}


